return mb;

      }

  }

 

  class ICICI extends RBI{ // Child class2

      double setInterestRate() {

          A=(P*r)/n+t;

          return A;

      }

     

      int setWithdrawalLimit() {

          withLimit=7000;

          return withLimit;

      }

  }

public class InhTest { //Tester code

public static void main(String args[]) {

SBI sbi = new SBI();

ICICI icici = new ICICI();

sbi.P=10.433;

sbi.r=7.42;

sbi.n=5;

sbi.t=7;

Double sbiInt=sbi.setInterestRate();

System.out.println("SBI interest rate is:"+sbiInt);

int iciciWL= icici.setWithdrawalLimit();

System.out.println("ICICI withdraw limit is:"+iciciWL);

}

}