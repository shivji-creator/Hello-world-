//out put 10;


public class Myclass
{
final static int x;

static {
x = 10;
}
public static void main(String[]
args) {
System.out.println(x);
}
}