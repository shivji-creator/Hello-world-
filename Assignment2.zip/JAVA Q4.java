class PopulationYears {
    public static void main(String args[]) {
        double initialPopulation = 80000;
        int years = 0;
        
        while (initialPopulation <= 150000) {
            initialPopulation = 1.05 * initialPopulation;
            years = years + 1;
        }

        System.out.println("Number of years: " + years);
    }
}