import java.util.*;
class smallestnumber {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        
       
        System.out.println("Input first number:");
        double numberx = sc.nextDouble();
        
        System.out.println("Input second number:");
        double numbery= sc.nextDouble();
        
        System.out.println("Input third number:");
        double numberz= sc.nextDouble();
        double smallestNumber;
        
        if (numberx < numbery && numberx < numberz) {
            smallestNumber = numberx;
        }

        else if (numbery < numberx  && numberx < numberz) {
            smallestNumber = numbery;
        }

        else {
            smallestNumber = numberz;
        }
        
        System.out.println("Smallest Number: " + smallestNumber);
        sc.close();
    }
}