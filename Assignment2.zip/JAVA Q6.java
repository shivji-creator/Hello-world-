class MultiplesOfThree {
    public static void main(String args[]) {
        int multiples = 3;

        while (multiples <= 36) {
            System.out.print(multiples + " ");
            multiples = multiples + 3;
        }
    }
}